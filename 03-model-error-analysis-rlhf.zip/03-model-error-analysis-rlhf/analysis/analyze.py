"""Load reviewer evaluations, validate them and find failure patterns."""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from typing import Dict, List

ERROR_TYPES = ("factual_error", "instruction_violation", "reasoning_error", "incomplete", "safety_issue",
               "inconsistency", "formatting_error", "tone_issue")
SEVERITIES = ("critical", "high", "medium", "low")

RECOMMENDATIONS = {
    "factual_error": "Add verified fact-check examples to the training data and require evidence for numeric and technical claims.",
    "instruction_violation": "Add training examples with explicit constraints (count, length, language, format) and reward strict compliance.",
    "reasoning_error": "Add step-by-step reasoning examples for arithmetic and logic, and verify final answers before output.",
    "incomplete": "Train the model to list every sub-question in the prompt and confirm each one is answered.",
    "safety_issue": "Expand refusal and privacy examples; add red-team prompts for surveillance, deception and personal data to the regression set.",
    "inconsistency": "Add self-consistency checks so explanations do not contradict the stated answer.",
    "formatting_error": "Add examples of machine-readable-only outputs (no preface text) for JSON/CSV requests.",
    "tone_issue": "Add professional-tone rewrite examples and penalize hostile or sarcastic language.",
}


def load_evaluations(path: str) -> List[dict]:
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for n, r in enumerate(csv.DictReader(f), start=2):
            try:
                rating = int(r["rating"])
            except ValueError:
                raise ValueError(f"line {n}: rating must be an integer 1-5") from None
            if not 1 <= rating <= 5:
                raise ValueError(f"line {n}: rating {rating} outside 1-5")
            et, sev = r["error_type"], r["severity"]
            if rating == 5:
                if et != "none" or sev:
                    raise ValueError(f"line {n}: a rating of 5 must have error_type 'none' and no severity")
            else:
                if et not in ERROR_TYPES:
                    raise ValueError(f"line {n}: unknown error_type {et!r}")
                if sev not in SEVERITIES:
                    raise ValueError(f"line {n}: unknown severity {sev!r}")
                if not r["recommended_fix"].strip():
                    raise ValueError(f"line {n}: recommended_fix is required when rating is below 5")
            if not r["justification"].strip():
                raise ValueError(f"line {n}: justification is required")
            rows.append({**r, "rating": rating})
    return rows


def weak_justifications(rows: List[dict], min_words: int = 8) -> List[str]:
    """Reviewer self-check: feedback on a flawed response (rating below 5) that is too short to be actionable."""
    return [r["id"] for r in rows if r["rating"] < 5 and len(r["justification"].split()) < min_words]


def summarize(rows: List[dict]) -> dict:
    n = len(rows)
    errors = [r for r in rows if r["rating"] < 5]
    by_type = Counter(r["error_type"] for r in errors)
    by_sev = Counter(r["severity"] for r in errors)
    dom = defaultdict(list)
    for r in rows:
        dom[r["domain"]].append(r)
    by_domain = {
        d: {"n": len(v), "avg_rating": sum(x["rating"] for x in v) / len(v),
            "error_rate": sum(1 for x in v if x["rating"] < 5) / len(v)}
        for d, v in dom.items()
    }
    return {
        "total": n,
        "avg_rating": sum(r["rating"] for r in rows) / n,
        "pass_rate": sum(1 for r in rows if r["rating"] >= 4) / n,
        "error_count": len(errors),
        "by_type": dict(by_type.most_common()),
        "by_severity": {s: by_sev.get(s, 0) for s in SEVERITIES},
        "by_domain": by_domain,
        "critical_and_high": [r for r in errors if r["severity"] in ("critical", "high")],
    }


def recommend(summary: dict, share_threshold: float = 0.15) -> List[str]:
    """Rule-based: safety issues always; other error types when they are at least 15% of all errors."""
    out, total = [], summary["error_count"]
    for et, count in summary["by_type"].items():
        if et == "safety_issue" or (total and count / total >= share_threshold):
            out.append(f"**{et}** ({count} of {total} errors): {RECOMMENDATIONS[et]}")
    return out
