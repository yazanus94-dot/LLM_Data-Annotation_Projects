import argparse
import sys

from .report import build_report


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="analysis", description="Error analysis report from reviewer evaluations.")
    p.add_argument("csv", nargs="?", default="data/evaluations.csv")
    p.add_argument("--out", help="write the Markdown report here")
    args = p.parse_args(argv)
    report = build_report(args.csv)
    if args.out:
        open(args.out, "w", encoding="utf-8").write(report)
        print(f"Report written to {args.out}")
    else:
        print(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
