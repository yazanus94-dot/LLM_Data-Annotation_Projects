from __future__ import annotations

from .analyze import SEVERITIES, load_evaluations, recommend, summarize, weak_justifications


def build_report(csv_path: str) -> str:
    rows = load_evaluations(csv_path)
    s = summarize(rows)
    worst = sorted(s["by_domain"].items(), key=lambda kv: (-kv[1]["error_rate"], kv[0]))
    top_type = next(iter(s["by_type"]))
    out = ["# Model Error Analysis Report", "",
           "## Executive summary", "",
           f"{s['total']} responses were reviewed. The average rating is **{s['avg_rating']:.2f} / 5** and **{s['pass_rate']:.0%}** "
           f"of responses were rated 4 or higher. **{s['error_count']}** responses contain an error; "
           f"**{s['by_severity']['critical']} critical** and **{s['by_severity']['high']} high** severity issues need attention first.",
           f"The most frequent error type is **{top_type}** ({s['by_type'][top_type]}). "
           f"The weakest domain is **{worst[0][0]}** (error rate {worst[0][1]['error_rate']:.0%}).", "",
           "## Errors by type", "", "| Error type | Count | Share of errors |", "|---|---|---|"]
    out += [f"| {k} | {v} | {v / s['error_count']:.0%} |" for k, v in s["by_type"].items()]
    out += ["", "## Errors by severity", "", "| Severity | Count |", "|---|---|"]
    out += [f"| {k} | {s['by_severity'][k]} |" for k in SEVERITIES]
    out += ["", "## Results by domain", "", "| Domain | Reviewed | Avg rating | Error rate |", "|---|---|---|---|"]
    out += [f"| {d} | {v['n']} | {v['avg_rating']:.2f} | {v['error_rate']:.0%} |" for d, v in worst]
    out += ["", "## Critical and high severity findings", "", "| ID | Severity | Type | Evidence and justification |", "|---|---|---|---|"]
    order = {x: i for i, x in enumerate(SEVERITIES)}
    for r in sorted(s["critical_and_high"], key=lambda r: (order[r["severity"]], r["id"])):
        out.append(f"| {r['id']} | {r['severity']} | {r['error_type']} | {r['justification']} |")
    out += ["", "## Recommendations", ""]
    out += [f"{i}. {t}" for i, t in enumerate(recommend(s), 1)]
    weak = weak_justifications(rows)
    out += ["", "## Reviewer feedback quality check", "",
            f"Justifications shorter than 8 words: {weak if weak else 'none'}"]
    return "\n".join(out) + "\n"
