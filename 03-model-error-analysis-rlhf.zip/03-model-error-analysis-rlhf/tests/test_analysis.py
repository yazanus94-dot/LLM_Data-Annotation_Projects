import os
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from analysis import load_evaluations, summarize, weak_justifications  # noqa: E402
from analysis.analyze import recommend  # noqa: E402
from analysis.report import build_report  # noqa: E402

CSV = os.path.join(ROOT, "data", "evaluations.csv")
HEADER = "id,domain,prompt,response,rating,error_type,severity,justification,recommended_fix\n"


def write(body):
    d = tempfile.mkdtemp()
    p = os.path.join(d, "e.csv")
    open(p, "w", encoding="utf-8").write(HEADER + body)
    return p


def fails(body, text):
    try:
        load_evaluations(write(body))
    except ValueError as e:
        return text in str(e)
    return False


def test_sample_data_loads_and_has_expected_counts():
    rows = load_evaluations(CSV)
    s = summarize(rows)
    assert s["total"] == 34 and s["error_count"] == 19
    assert s["by_type"]["factual_error"] == 4
    assert s["by_severity"] == {"critical": 1, "high": 5, "medium": 11, "low": 2}


def test_summary_metrics():
    s = summarize(load_evaluations(CSV))
    assert round(s["avg_rating"], 2) == 3.18
    assert abs(s["pass_rate"] - 15 / 34) < 1e-9
    assert s["by_domain"]["safety"]["error_rate"] == 0.5


def test_validation_rejects_bad_rows():
    assert fails("1,d,p,r,6,factual_error,high,some justification text here ok,fix\n", "outside 1-5")
    assert fails("1,d,p,r,abc,factual_error,high,j,fix\n", "integer")
    assert fails("1,d,p,r,2,made_up,high,j,fix\n", "unknown error_type")
    assert fails("1,d,p,r,2,factual_error,urgent,j,fix\n", "unknown severity")
    assert fails("1,d,p,r,5,factual_error,,j,\n", "rating of 5")
    assert fails("1,d,p,r,2,factual_error,high,j,\n", "recommended_fix")
    assert fails("1,d,p,r,5,none,,,\n", "justification")


def test_weak_justification_detection():
    p = write("1,d,p,r,2,factual_error,high,Wrong.,fix it\n"
              "2,d,p,r,2,factual_error,high,The answer states 25 but the correct value is 30 so it is wrong.,fix it\n"
              "3,d,p,r,5,none,,Good.,\n")
    assert weak_justifications(load_evaluations(p)) == ["1"]  # short praise on a correct answer is fine


def test_recommendations_include_safety_and_frequent_types():
    recs = recommend(summarize(load_evaluations(CSV)))
    text = " ".join(recs)
    assert "safety_issue" in text and "factual_error" in text
    assert "tone_issue" not in text  # 1 of 19 errors, below the 15% threshold


def test_report_contains_sections_and_critical_finding():
    r = build_report(CSV)
    for h in ("Executive summary", "Errors by type", "Results by domain", "Critical and high severity findings", "Recommendations"):
        assert h in r
    assert "E14" in r and "34 responses were reviewed" in r
