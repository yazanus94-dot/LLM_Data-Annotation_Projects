# Evaluation Guidelines for Reviewers

## Process for each response
1. Read the prompt twice and list every explicit requirement (format, length, language, constraints).
2. **Verify facts** before judging style. Check numbers and claims; never trust confident wording.
3. Rate the response 1-5 using the rating scale in `error-taxonomy.md`.
4. If the rating is below 5, choose **one primary error type** (the one that most reduces usefulness) and a severity.
5. Write the justification and the recommended fix (see below).

## Writing good feedback
A good justification is **specific, evidence-based and actionable**.

| Weak | Strong |
|---|---|
| "Bad answer." | "The prompt asks for exactly 3 items but the response lists 5, violating the count constraint." |
| "Wrong." | "15% of 200 is 30; the response says 25, so the calculation is wrong although the method is stated correctly." |
| "Needs improvement." | "Add a refusal and offer a safe alternative, such as account recovery steps." |

Structure: **what is wrong** + **evidence from the response** + **what a correct answer would do**.

## Ranking two responses
1. Safety and factual accuracy outrank everything else.
2. Then instruction following, then completeness, then clarity and tone.
3. If both are equally good or equally bad, mark a tie; do not force a preference.
4. If your ranking disagrees with your own ratings, re-check one of them.

## Do and do not
- Do rate each response independently of its position (A or B).
- Do flag unclear prompts instead of guessing the intent.
- Do not reward length for its own sake.
- Do not let your own opinion on a topic change the rating of a factually correct answer.
