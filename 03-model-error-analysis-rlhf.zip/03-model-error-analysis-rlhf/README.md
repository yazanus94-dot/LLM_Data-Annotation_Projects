# Model Error Analysis & RLHF Evaluation

A complete **model evaluation workflow**: reviewer guidelines, an error taxonomy, rated and annotated model responses with written justifications, and an analysis tool that turns the reviews into failure patterns and **actionable recommendations** for improving model quality and training data.

> The prompts, responses and ratings are **synthetic examples** written for this demonstration (34 reviewed responses, 19 with deliberate errors).

## The workflow
1. **Guidelines** (`docs/evaluation-guidelines.md`): how to verify facts, rate 1-5, rank two responses, and write specific, evidence-based feedback.
2. **Taxonomy** (`docs/error-taxonomy.md`): 8 error types, 4 severity levels and a rating scale, so every reviewer labels errors the same way.
3. **Evaluations** (`data/evaluations.csv`): each response has a rating, error type, severity, justification and recommended fix.
4. **Analysis** (`python -m analysis`): validates the data, finds patterns and writes `reports/error-analysis-report.md`.

## Sample findings (from the report)
- 34 responses reviewed, average rating **3.18 / 5**, 44% rated 4 or higher
- 19 responses contain an error: **1 critical, 5 high, 11 medium, 2 low**
- Most frequent error: **factual_error** (21% of errors); the critical one is a safety issue (covert surveillance advice)
- Weakest domains: reasoning (100% error rate), software testing (67%), knowledge (60%)
- Recommendations are generated per error type, for example: add verified fact-check and arithmetic reasoning examples, and add red-team prompts for surveillance, deception and personal data

## Built-in data validation
The loader rejects: ratings outside 1-5, unknown error types or severities, a rating of 5 that still has an error type, missing justifications and missing fixes for flawed responses. It also flags **weak feedback** (flawed responses with justifications under 8 words), a self-check for reviewer quality.

## Run it
```bash
python -m analysis data/evaluations.csv --out reports/error-analysis-report.md
pytest -q
```

## Project layout
| Path | Purpose |
|---|---|
| `docs/evaluation-guidelines.md` | Reviewer process, feedback examples, ranking rules |
| `docs/error-taxonomy.md` | Error types, severity, rating scale |
| `data/evaluations.csv` | 34 annotated responses |
| `analysis/` | Loader with validation, summary statistics, recommendations, report builder |
| `reports/error-analysis-report.md` | Example output |
| `tests/` | 6 automated tests |

## Skills demonstrated
AI model evaluation, RLHF-style rating and feedback, error analysis, written documentation, actionable recommendations, data validation, Python, unit testing.

## Author
Yazan Aljabari - QA Engineer
