# Annotation Guidelines: Support Message Intent

Label each customer message with **one** intent. Use only the label names exactly as written (lowercase, underscore).

| Label | Use when the customer... | Example |
|---|---|---|
| `bug_report` | describes something that is broken or behaves incorrectly | "The app crashes when I zoom past 800%." |
| `feature_request` | asks for something new or an improvement | "Please add a dark mode." |
| `question` | asks how to do something or asks for information | "Where can I find the export settings?" |
| `praise` | expresses satisfaction or thanks | "Your pen tool feels amazing." |
| `complaint` | expresses dissatisfaction about price, service or experience without describing a specific malfunction | "Support took five days to answer." |

## Edge-case rules
1. **Bug vs complaint:** a specific malfunction you can reproduce is a `bug_report`; general frustration is a `complaint`. "The app feels slower with every release" is a `complaint` (no reproducible steps).
2. **Question vs feature request:** "Can I use the app offline?" is a `question`; "Please add offline mode" is a `feature_request`.
3. **Mixed messages:** choose the **main** intent, the one the customer wants handled first.
4. **Unclear or empty text:** do not guess. Flag the item as `unclear` in the notes column and escalate.
5. **Do not use outside knowledge** of the product; label only what the message says.

## Quality targets
- Agreement between annotators: Cohen's kappa of at least 0.60
- Accuracy on the gold set: at least 85%
- Zero invalid labels, zero empty items in the delivered dataset

## Review process
1. Annotate independently. 2. Run the quality report. 3. Adjudicate disagreements. 4. Update this guide with each new edge case.
