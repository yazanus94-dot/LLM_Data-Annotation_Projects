# Data Annotation Quality Toolkit

A Python toolkit and set of guidelines for **checking the quality of labeled datasets** before they are used to train or evaluate AI models. It finds invalid labels, empty or duplicate items, conflicting labels, annotator disagreement and weak annotators, then writes a report with a verdict and recommendations.

> The dataset (customer support messages for a design app, labeled by 3 annotators) is **synthetic**, with realistic problems planted on purpose so the report has something to find.

## What it checks
| Check | Why it matters |
|---|---|
| Invalid labels (typos, wrong casing, spaces) | Bad labels silently corrupt training data |
| Empty text, whitespace, very short text | Items that cannot be labeled reliably |
| Missing annotations | Every item must be labeled by every annotator |
| Duplicate texts (ignoring case and punctuation) | Inflates the dataset and leaks between train/test |
| **Duplicates with conflicting labels** | Teaches the model two answers for one input |
| Label distribution and imbalance | Skewed data biases the model |
| Inter-annotator agreement (Cohen's kappa per pair) | Shows whether the guidelines are clear |
| Accuracy against a gold set, with the most common confusion | Identifies annotators who need coaching |

## Run it
```bash
python -m annotation_qa data --out reports/sample_quality_report.md
pytest -q
```
The command returns exit code 1 when the verdict is NEEDS REVIEW, so it can block a data delivery in CI.

## Sample result (from `reports/sample_quality_report.md`)
- **Verdict: NEEDS REVIEW**
- 3 invalid labels (`bug`, `feature request`, `Praise`), 1 empty item, 1 missing annotation
- 1 duplicate text labeled `complaint` once and `feature_request` once
- Kappa: annotator 1 vs 2 = 0.96 (almost perfect), annotator 3 vs others about 0.47 (moderate)
- Gold accuracy: annotator 3 is at 58% and is flagged for coaching; the most common confusion is question -> feature_request

## Project layout
| Path | Purpose |
|---|---|
| `data/guidelines.md` | Annotation guidelines: label definitions, edge-case rules, quality targets, review process |
| `data/annotations.csv`, `data/gold.csv`, `data/config.json` | Sample data, gold labels, allowed labels |
| `annotation_qa/checks.py` | Data quality checks |
| `annotation_qa/agreement.py` | Kappa, majority vote, disagreement items |
| `annotation_qa/gold.py` | Accuracy and confusion against gold labels |
| `annotation_qa/report.py` | Verdict, thresholds, recommendations |
| `tests/` | 13 automated tests |

## Quality thresholds
Cohen's kappa of at least 0.60, gold accuracy of at least 85%, zero invalid labels, zero empty items. Edit them in `annotation_qa/report.py`.

## Skills demonstrated
Data annotation and labeling QA, guideline writing, inter-annotator agreement, data integrity checks, Python, unit testing, technical documentation.

## Author
Yazan Aljabari - QA Engineer
