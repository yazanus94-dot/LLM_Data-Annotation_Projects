# Data Quality Report: Customer support intent labels (synthetic)

**Verdict: NEEDS REVIEW**

- 3 invalid label(s)
- 1 item(s) with empty text
- 1 item(s) not labeled by every annotator
- 1 duplicate text(s) with conflicting labels
- kappa below 0.6 for annotator_1/annotator_3, annotator_2/annotator_3
- gold accuracy below 85% for annotator_3

Items: 33 | Annotators: 3 | Labels collected: 98 | Gold items: 12

## 1. Schema and completeness

- Invalid labels: **3**
  - I03 by annotator_2: `bug`
  - I12 by annotator_3: `feature request`
  - I20 by annotator_3: `Praise`
- Empty text items: **1** ['I33']
- Items missing an annotation: **1** {'I18': ['annotator_2']}
- Text issues: **1** ['I31: leading/trailing whitespace']

## 2. Duplicates

- Duplicate text groups: **2** [['I07', 'I31'], ['I25', 'I32']]
- Duplicates with conflicting labels: **1**
  - ['I25', 'I32'] -> {'I25': 'complaint', 'I32': 'feature_request'}

## 3. Label distribution

| Label | Share |
|---|---|
| bug_report | 19% |
| complaint | 24% |
| feature_request | 23% |
| praise | 13% |
| question | 21% |

Distribution is reasonably balanced.

## 4. Inter-annotator agreement

| Pair | Cohen's kappa | Meaning |
|---|---|---|
| annotator_1 vs annotator_2 | 0.96 | almost perfect |
| annotator_1 vs annotator_3 | 0.47 | moderate |
| annotator_2 vs annotator_3 | 0.48 | moderate |

Items with disagreement: **13** of 33

## 5. Accuracy against gold labels

| Annotator | Accuracy | Most common confusion (gold -> given) |
|---|---|---|
| annotator_1 | 100% (12/12) | none |
| annotator_2 | 92% (11/12) | bug_report -> bug |
| annotator_3 | 58% (7/12) | question -> feature_request |

## 6. Recommendations

1. Add label validation (dropdown or strict schema) to the annotation tool to stop typos and casing errors.
2. Deduplicate the dataset before labeling; resolve conflicting duplicates with an adjudicator.
3. Retrain or coach annotator_3 using the guideline edge cases and recheck on a new gold set.
4. Run a calibration session on the items with disagreement and update the guideline edge-case rules.
5. Fix data export: empty texts and missing annotations should be blocked before delivery.
