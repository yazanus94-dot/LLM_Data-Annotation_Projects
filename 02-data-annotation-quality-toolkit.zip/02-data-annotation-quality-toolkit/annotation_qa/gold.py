"""Score annotators against a gold (expert-labeled) set."""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Sequence


def annotator_accuracy(rows: Sequence[dict], gold: Dict[str, str]) -> Dict[str, dict]:
    stats: Dict[str, dict] = defaultdict(lambda: {"correct": 0, "total": 0, "errors": []})
    for r in rows:
        if r["item_id"] in gold:
            s = stats[r["annotator"]]
            s["total"] += 1
            if r["label"] == gold[r["item_id"]]:
                s["correct"] += 1
            else:
                s["errors"].append((r["item_id"], gold[r["item_id"]], r["label"]))
    for s in stats.values():
        s["accuracy"] = s["correct"] / s["total"] if s["total"] else 0.0
    return dict(stats)


def most_confused(errors: List[tuple]) -> List[tuple]:
    """(gold, given) pairs ordered by frequency."""
    counts: Dict[tuple, int] = defaultdict(int)
    for _, g, given in errors:
        counts[(g, given)] += 1
    return sorted(counts.items(), key=lambda kv: -kv[1])
