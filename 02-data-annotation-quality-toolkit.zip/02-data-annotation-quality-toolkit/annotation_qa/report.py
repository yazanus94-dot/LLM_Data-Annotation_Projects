"""Build the data quality report and a pass/needs-review verdict."""
from __future__ import annotations

import json
import os
from typing import List

from .agreement import disagreement_items, interpret_kappa, pairwise_kappa
from .checks import (find_conflicting_duplicates, find_duplicate_texts, find_empty_text, find_invalid_labels,
                     find_missing_annotations, find_text_issues, imbalanced_labels, label_distribution)
from .gold import annotator_accuracy, most_confused
from .io import load_annotations, load_gold

MIN_KAPPA = 0.60
MIN_GOLD_ACCURACY = 0.85


def build_report(data_dir: str) -> str:
    cfg = json.load(open(os.path.join(data_dir, "config.json"), encoding="utf-8"))
    allowed = cfg["labels"]
    rows = load_annotations(os.path.join(data_dir, "annotations.csv"))
    gold = load_gold(os.path.join(data_dir, "gold.csv"))
    annotators = sorted({r["annotator"] for r in rows})
    items = {r["item_id"] for r in rows}

    invalid = find_invalid_labels(rows, allowed)
    empty = find_empty_text(rows)
    missing = find_missing_annotations(rows, annotators)
    dups = find_duplicate_texts(rows)
    conflicts = find_conflicting_duplicates(rows, allowed)
    text_issues = find_text_issues(rows)
    dist = label_distribution([r for r in rows if r["label"] in allowed])
    kappas = pairwise_kappa(rows, allowed)
    acc = annotator_accuracy([r for r in rows if r["label"] in allowed] + [r for r in invalid], gold)
    disagreements = disagreement_items(rows, allowed)

    problems: List[str] = []
    if invalid: problems.append(f"{len(invalid)} invalid label(s)")
    if empty: problems.append(f"{len(empty)} item(s) with empty text")
    if missing: problems.append(f"{len(missing)} item(s) not labeled by every annotator")
    if conflicts: problems.append(f"{len(conflicts)} duplicate text(s) with conflicting labels")
    low_k = [f"{a}/{b}" for (a, b), k in kappas.items() if k < MIN_KAPPA]
    if low_k: problems.append(f"kappa below {MIN_KAPPA} for {', '.join(low_k)}")
    low_acc = [a for a, s in acc.items() if s["accuracy"] < MIN_GOLD_ACCURACY]
    if low_acc: problems.append(f"gold accuracy below {MIN_GOLD_ACCURACY:.0%} for {', '.join(low_acc)}")

    verdict = "NEEDS REVIEW" if problems else "PASS"
    out = [f"# Data Quality Report: {cfg['dataset']}", "",
           f"**Verdict: {verdict}**", ""]
    out += [f"- {p}" for p in problems] or ["- no blocking problems"]
    out += ["", f"Items: {len(items)} | Annotators: {len(annotators)} | Labels collected: {len(rows)} | Gold items: {len(gold)}", "",
            "## 1. Schema and completeness", "",
            f"- Invalid labels: **{len(invalid)}**"]
    out += [f"  - {r['item_id']} by {r['annotator']}: `{r['label']}`" for r in invalid]
    out += [f"- Empty text items: **{len(empty)}** {empty}",
            f"- Items missing an annotation: **{len(missing)}** {dict(missing)}",
            f"- Text issues: **{len(text_issues)}** {[t['item_id'] + ': ' + t['issue'] for t in text_issues]}", "",
            "## 2. Duplicates", "",
            f"- Duplicate text groups: **{len(dups)}** {dups}",
            f"- Duplicates with conflicting labels: **{len(conflicts)}**"]
    out += [f"  - {c['items']} -> {c['labels']}" for c in conflicts]
    out += ["", "## 3. Label distribution", "", "| Label | Share |", "|---|---|"]
    out += [f"| {k} | {v:.0%} |" for k, v in dist.items()]
    skew = imbalanced_labels(dist)
    out += ["", f"Imbalance warning: {skew}" if skew else "Distribution is reasonably balanced.", "",
            "## 4. Inter-annotator agreement", "", "| Pair | Cohen's kappa | Meaning |", "|---|---|---|"]
    out += [f"| {a} vs {b} | {k:.2f} | {interpret_kappa(k)} |" for (a, b), k in kappas.items()]
    out += ["", f"Items with disagreement: **{len(disagreements)}** of {len(items)}", "",
            "## 5. Accuracy against gold labels", "", "| Annotator | Accuracy | Most common confusion (gold -> given) |", "|---|---|---|"]
    for a in sorted(acc):
        mc = most_confused(acc[a]["errors"])
        conf = f"{mc[0][0][0]} -> {mc[0][0][1]}" if mc else "none"
        out.append(f"| {a} | {acc[a]['accuracy']:.0%} ({acc[a]['correct']}/{acc[a]['total']}) | {conf} |")
    out += ["", "## 6. Recommendations", ""]
    recs = []
    if invalid: recs.append("Add label validation (dropdown or strict schema) to the annotation tool to stop typos and casing errors.")
    if conflicts or dups: recs.append("Deduplicate the dataset before labeling; resolve conflicting duplicates with an adjudicator.")
    if low_acc: recs.append(f"Retrain or coach {', '.join(low_acc)} using the guideline edge cases and recheck on a new gold set.")
    if low_k: recs.append("Run a calibration session on the items with disagreement and update the guideline edge-case rules.")
    if empty or missing: recs.append("Fix data export: empty texts and missing annotations should be blocked before delivery.")
    out += [f"{i}. {r}" for i, r in enumerate(recs, 1)] or ["No actions required."]
    return "\n".join(out) + "\n"
