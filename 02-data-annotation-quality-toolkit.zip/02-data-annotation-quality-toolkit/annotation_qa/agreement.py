"""Inter-annotator agreement."""
from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations
from typing import Dict, List, Optional, Sequence, Tuple


def cohens_kappa(a: Sequence[str], b: Sequence[str]) -> float:
    if len(a) != len(b) or not a:
        raise ValueError("label lists must be non-empty and the same length")
    n = len(a)
    observed = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    expected = sum((ca[k] / n) * (cb[k] / n) for k in set(ca) | set(cb))
    return 1.0 if expected == 1 else (observed - expected) / (1 - expected)


def majority_label(labels: Sequence[str]) -> Optional[str]:
    """Most common label, or None on a tie / no labels."""
    if not labels:
        return None
    top = Counter(labels).most_common(2)
    if len(top) > 1 and top[0][1] == top[1][1]:
        return None
    return top[0][0]


def _by_annotator(rows: Sequence[dict], allowed: Optional[Sequence[str]] = None) -> Dict[str, Dict[str, str]]:
    out: Dict[str, Dict[str, str]] = defaultdict(dict)
    for r in rows:
        if allowed is None or r["label"] in allowed:
            out[r["annotator"]][r["item_id"]] = r["label"]
    return out


def pairwise_kappa(rows: Sequence[dict], allowed: Optional[Sequence[str]] = None) -> Dict[Tuple[str, str], float]:
    data = _by_annotator(rows, allowed)
    result = {}
    for x, y in combinations(sorted(data), 2):
        shared = sorted(set(data[x]) & set(data[y]))
        if shared:
            result[(x, y)] = cohens_kappa([data[x][i] for i in shared], [data[y][i] for i in shared])
    return result


def interpret_kappa(k: float) -> str:
    if k < 0.2: return "poor"
    if k < 0.4: return "fair"
    if k < 0.6: return "moderate"
    if k < 0.8: return "substantial"
    return "almost perfect"


def disagreement_items(rows: Sequence[dict], allowed: Optional[Sequence[str]] = None) -> List[dict]:
    """Items where annotators did not all choose the same label."""
    labels: Dict[str, Dict[str, str]] = defaultdict(dict)
    text = {}
    for r in rows:
        if allowed is None or r["label"] in allowed:
            labels[r["item_id"]][r["annotator"]] = r["label"]
        text[r["item_id"]] = r["text"]
    return [{"item_id": i, "text": text[i], "labels": l} for i, l in labels.items() if len(set(l.values())) > 1]
