"""Data-quality checks for labeled datasets."""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from typing import Dict, Iterable, List, Sequence

from .agreement import majority_label


def normalize_text(text: str) -> str:
    return " ".join(re.sub(r"[^\w\s]", "", text.lower()).split())


def find_invalid_labels(rows: Iterable[dict], allowed: Sequence[str]) -> List[dict]:
    """Labels outside the allowed set, including wrong casing, spaces and typos."""
    allowed_set = set(allowed)
    return [r for r in rows if r["label"] not in allowed_set]


def find_empty_text(rows: Iterable[dict]) -> List[str]:
    return sorted({r["item_id"] for r in rows if not (r["text"] or "").strip()})


def find_missing_annotations(rows: Iterable[dict], annotators: Sequence[str]) -> Dict[str, List[str]]:
    """item_id -> annotators who did not label it."""
    seen = defaultdict(set)
    for r in rows:
        seen[r["item_id"]].add(r["annotator"])
    return {i: sorted(set(annotators) - a) for i, a in seen.items() if set(annotators) - a}


def _items(rows: Iterable[dict]) -> Dict[str, str]:
    return {r["item_id"]: r["text"] for r in rows}


def find_duplicate_texts(rows: Iterable[dict]) -> List[List[str]]:
    """Groups of different item ids that contain the same text (ignoring case, spacing and punctuation)."""
    groups = defaultdict(list)
    for item_id, text in _items(rows).items():
        key = normalize_text(text)
        if key:
            groups[key].append(item_id)
    return [sorted(ids) for ids in groups.values() if len(ids) > 1]


def find_conflicting_duplicates(rows: Sequence[dict], allowed: Sequence[str]) -> List[dict]:
    """Duplicate texts whose consensus labels differ: the dataset teaches the model two answers for one input."""
    by_item = defaultdict(list)
    for r in rows:
        if r["label"] in allowed:
            by_item[r["item_id"]].append(r["label"])
    conflicts = []
    for ids in find_duplicate_texts(rows):
        labels = {i: majority_label(by_item[i]) for i in ids}
        if len({l for l in labels.values() if l}) > 1:
            conflicts.append({"items": ids, "labels": labels})
    return conflicts


def label_distribution(rows: Iterable[dict]) -> Dict[str, float]:
    counts = Counter(r["label"] for r in rows)
    total = sum(counts.values())
    return {k: v / total for k, v in sorted(counts.items())} if total else {}


def imbalanced_labels(dist: Dict[str, float], max_share: float = 0.4, min_share: float = 0.05) -> List[str]:
    return [k for k, v in dist.items() if v > max_share or v < min_share]


def find_text_issues(rows: Iterable[dict], min_words: int = 3) -> List[dict]:
    """Leading/trailing spaces and texts too short to label reliably."""
    issues, seen = [], set()
    for r in rows:
        if r["item_id"] in seen:
            continue
        seen.add(r["item_id"])
        t = r["text"] or ""
        if t != t.strip():
            issues.append({"item_id": r["item_id"], "issue": "leading/trailing whitespace"})
        if t.strip() and len(t.split()) < min_words:
            issues.append({"item_id": r["item_id"], "issue": f"fewer than {min_words} words"})
    return issues
