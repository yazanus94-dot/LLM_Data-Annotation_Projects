import csv
from typing import Dict, List

REQUIRED = {"item_id", "text", "annotator", "label"}


def load_annotations(path: str) -> List[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        missing = REQUIRED - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"{path}: missing columns {sorted(missing)}")
        return [dict(r) for r in reader]


def load_gold(path: str) -> Dict[str, str]:
    with open(path, newline="", encoding="utf-8") as f:
        return {r["item_id"]: r["label"] for r in csv.DictReader(f)}
