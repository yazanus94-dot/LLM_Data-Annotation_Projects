import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from annotation_qa import (annotator_accuracy, cohens_kappa, find_conflicting_duplicates, find_duplicate_texts,  # noqa: E402
                           find_empty_text, find_invalid_labels, find_missing_annotations, label_distribution,
                           load_annotations, load_gold, majority_label, pairwise_kappa)
from annotation_qa.agreement import disagreement_items  # noqa: E402
from annotation_qa.checks import find_text_issues, imbalanced_labels  # noqa: E402
from annotation_qa.report import build_report  # noqa: E402

LABELS = ["a", "b", "c"]


def row(i, text, ann, label):
    return {"item_id": i, "text": text, "annotator": ann, "label": label}


def test_kappa_known_values():
    assert cohens_kappa(["a", "a", "b", "b"], ["a", "a", "b", "b"]) == 1.0
    assert cohens_kappa(["a", "b", "a", "b"], ["b", "a", "b", "a"]) == -1.0
    assert abs(cohens_kappa(["a", "a", "b", "b"], ["a", "b", "a", "b"])) < 1e-9
    assert cohens_kappa(["a", "a"], ["a", "a"]) == 1.0


def test_kappa_requires_equal_non_empty_lists():
    for a, b in (([], []), (["a"], ["a", "b"])):
        try:
            cohens_kappa(a, b)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_majority_label():
    assert majority_label(["a", "a", "b"]) == "a"
    assert majority_label(["a", "b"]) is None
    assert majority_label([]) is None


def test_invalid_labels_include_casing_and_spaces():
    rows = [row("1", "t", "x", "a"), row("2", "t", "x", "A"), row("3", "t", "x", "a b"), row("4", "t", "x", "")]
    assert [r["item_id"] for r in find_invalid_labels(rows, LABELS)] == ["2", "3", "4"]


def test_empty_text_and_missing_annotations():
    rows = [row("1", "  ", "x", "a"), row("2", "hello there friend", "x", "a"), row("2", "hello there friend", "y", "a")]
    assert find_empty_text(rows) == ["1"]
    assert find_missing_annotations(rows, ["x", "y"]) == {"1": ["y"]}


def test_duplicates_ignore_case_spacing_and_punctuation():
    rows = [row("1", "Please add a dark mode.", "x", "a"), row("2", "please add a dark mode  ", "x", "a"),
            row("3", "something else entirely", "x", "b")]
    assert find_duplicate_texts(rows) == [["1", "2"]]


def test_conflicting_duplicates_use_consensus():
    same = [row("1", "dup text here", "x", "a"), row("1", "dup text here", "y", "a"),
            row("2", "Dup text here!", "x", "a"), row("2", "Dup text here!", "y", "a")]
    assert find_conflicting_duplicates(same, LABELS) == []
    diff = [row("1", "dup text here", "x", "a"), row("1", "dup text here", "y", "a"),
            row("2", "Dup text here!", "x", "b"), row("2", "Dup text here!", "y", "b")]
    c = find_conflicting_duplicates(diff, LABELS)
    assert len(c) == 1 and c[0]["labels"] == {"1": "a", "2": "b"}


def test_distribution_and_imbalance():
    rows = [row(str(i), "t", "x", "a") for i in range(9)] + [row("9", "t", "x", "b")]
    dist = label_distribution(rows)
    assert dist == {"a": 0.9, "b": 0.1}
    assert imbalanced_labels(dist) == ["a"]


def test_text_issues():
    rows = [row("1", " padded text here ", "x", "a"), row("2", "hi", "x", "a"), row("3", "fine text here", "x", "a")]
    issues = {(i["item_id"], i["issue"]) for i in find_text_issues(rows)}
    assert ("1", "leading/trailing whitespace") in issues and ("2", "fewer than 3 words") in issues
    assert not any(i[0] == "3" for i in issues)


def test_pairwise_kappa_and_disagreements():
    rows = [row("1", "t", "x", "a"), row("1", "t", "y", "a"), row("2", "t", "x", "b"), row("2", "t", "y", "c")]
    assert ("x", "y") in pairwise_kappa(rows, LABELS)
    d = disagreement_items(rows, LABELS)
    assert [i["item_id"] for i in d] == ["2"]


def test_gold_accuracy_and_errors():
    rows = [row("1", "t", "x", "a"), row("2", "t", "x", "b"), row("3", "t", "x", "a")]
    acc = annotator_accuracy(rows, {"1": "a", "2": "a"})
    assert acc["x"]["accuracy"] == 0.5 and acc["x"]["errors"] == [("2", "a", "b")]


def test_sample_dataset_has_the_planted_problems():
    d = os.path.join(ROOT, "data")
    rows = load_annotations(os.path.join(d, "annotations.csv"))
    labels = ["bug_report", "feature_request", "question", "praise", "complaint"]
    assert {r["label"] for r in find_invalid_labels(rows, labels)} == {"feature request", "Praise", "bug"}
    assert find_empty_text(rows) == ["I33"]
    assert find_missing_annotations(rows, ["annotator_1", "annotator_2", "annotator_3"]) == {"I18": ["annotator_2"]}
    assert ["I07", "I31"] in find_duplicate_texts(rows) and ["I25", "I32"] in find_duplicate_texts(rows)
    assert [c["items"] for c in find_conflicting_duplicates(rows, labels)] == [["I25", "I32"]]
    assert len(load_gold(os.path.join(d, "gold.csv"))) == 12


def test_report_verdict_and_sections():
    report = build_report(os.path.join(ROOT, "data"))
    assert "**Verdict: NEEDS REVIEW**" in report
    for h in ("Schema and completeness", "Duplicates", "Label distribution", "Inter-annotator agreement", "Accuracy against gold", "Recommendations"):
        assert h in report
