# LLM Output Test Harness

A Python framework for **designing, executing and documenting test cases for AI model outputs**. Requirements such as "answer in JSON", "under 20 words", "refuse harmful requests" or "never output real-looking personal data" become automatic pass/fail checks, and every failure becomes a ready-to-file defect report.

## Highlights
- **25 test cases** across 9 categories: instruction following, factual accuracy, safety, privacy, format, language (including Arabic), robustness, consistency and length
- **15 reusable checks**: contains, regex, exact match, word limits, numbered items, valid JSON and keys, Arabic script, refusal detection, PII detection and more
- **Consistency testing**: runs a prompt several times and flags unstable answers
- **Auto-generated defect reports** (steps, expected, actual, severity) and a **Go / No-Go recommendation**
- **Pluggable models**: works offline with a built-in mock model, or with any function `prompt -> answer`
- 12 automated tests

## Quick start
```bash
python -m harness cases --model mock          # offline demo (14 of 25 pass on purpose)
python -m harness cases --model mypkg.client:ask   # your own model function
pytest -q
```
Outputs are written to `reports/`: `summary.md`, `results.csv` and one file per failure in `reports/defects/`.

> The mock model returns canned answers, some deliberately flawed, so the demo shows realistic failures (wrong arithmetic, a compliant keylogger, a fake email address, extra text around JSON). Replace it with a real model to test real behavior.

## Sample result
```
14/25 passed. NO-GO: at least one critical failure (safety or privacy).
```
| Severity | Failed |
|---|---|
| critical | 2 (SF-002 malware request, PV-001 personal data) |
| high | 2 |
| medium | 5 |
| low | 2 |

## Add your own case
```json
{
  "id": "FM-004", "category": "format", "severity": "high",
  "title": "Valid JSON only", "prompt": "Return only a JSON object with the key status.",
  "checks": [{"type": "valid_json"}, {"type": "json_keys", "keys": ["status"]}]
}
```

## Project layout
| Path | Purpose |
|---|---|
| `cases/` | Test cases as JSON data |
| `harness/checks.py` | Check library |
| `harness/runner.py` | Case loading, execution, consistency runs |
| `harness/report.py` | Summary, defect reports, recommendation |
| `docs/test-strategy-for-ai-systems.md` | Test dimensions, severity, workflow, exit criteria |
| `reports/` | Example output |

## Skills demonstrated
Test case design for AI outputs, test execution, defect reporting, severity and release criteria, Python, test automation, documentation.

## Author
Yazan Aljabari - QA Engineer
