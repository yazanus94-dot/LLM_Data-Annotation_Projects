# Test Strategy for AI / LLM Outputs

## Why testing AI differs from testing normal software
| Challenge | What it means | How this project handles it |
|---|---|---|
| No single correct output | Many answers can be acceptable | Test **properties** (format, limits, required facts) instead of exact text |
| Non-determinism | The same prompt can give different answers | `repeat` runs and a consistency check |
| Hidden failure modes | Wrong answers look confident | Separate factual, safety, privacy, format and robustness categories |
| Subjective quality | Tone and helpfulness need people | Automated checks for what is measurable; human rubric review for the rest (see the Model Error Analysis project) |

## Test dimensions
| Category | Question it answers | Example case |
|---|---|---|
| instruction_following | Does it obey explicit constraints? | Exactly 3 numbered items |
| factual_accuracy | Are verifiable facts right? | 15% of 200 |
| safety | Does it refuse harmful requests? | Keylogger request |
| privacy | Does it avoid inventing real-looking personal data? | Sample customer record |
| format | Is the output machine-readable? | JSON only, no extra text |
| language | Does it respect the requested language and script? | Arabic answer |
| robustness | Does it cope with typos and casing? | "wat dose QA stnad for?" |
| consistency | Is it stable across runs? | Same answer 3 times |
| length | Does it respect size limits? | Under 20 words |

## Severity
| Severity | Definition | Release impact |
|---|---|---|
| Critical | Harmful, unsafe or privacy-violating output | Blocks release |
| High | Wrong facts or broken machine-readable format | Blocks release |
| Medium | Instruction or language failure, workaround exists | Track as known issue |
| Low | Style or minor limit breaches | Fix when convenient |

## Execution workflow
1. Write cases as data in `cases/*.json` (prompt, category, severity, checks).
2. Run `python -m harness cases --model mock` (or plug in a real model).
3. Review `reports/summary.md`, then each file in `reports/defects/`.
4. Raise defects, add fixed cases to the regression set, re-run after every model or prompt change.

## Exit criteria
No open critical or high failures; all categories above 90% pass rate; known medium/low issues documented.
