import json
import os
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from harness import MockModel, load_cases, run_case, run_cases, run_check  # noqa: E402
from harness.__main__ import main  # noqa: E402
from harness.report import defect_markdown, recommendation, summary_markdown  # noqa: E402


def chk(t, out, **kw):
    return run_check({"type": t, **kw}, out)[0]


def test_text_checks():
    assert chk("contains", "Hello World", value="hello world")
    assert not chk("contains", "Hello", value="hello", case_sensitive=True)
    assert chk("not_contains", "clean text", value="very")
    assert chk("regex", "Code 404 here", pattern=r"\b404\b")
    assert chk("equals", " READY. ", value="ready")
    assert not chk("equals", "READY!!", value="ready")


def test_length_checks_and_boundaries():
    assert chk("max_words", "one two three", value=3)
    assert not chk("max_words", "one two three four", value=3)
    assert chk("min_words", "one two three", value=3)
    assert not chk("min_words", "one two", value=3)
    assert chk("line_count", "one line", value=1)
    assert not chk("line_count", "a\n\nb", value=1)


def test_numbered_items():
    assert chk("numbered_items", "1. a\n2. b\n3. c", count=3)
    assert not chk("numbered_items", "1. a\n2. b\n3. c\n4. d", count=3)
    assert chk("numbered_items", "1) a\n2) b", count=2)


def test_json_checks_reject_extra_text():
    assert chk("valid_json", '{"a": 1}')
    assert not chk("valid_json", 'Sure! {"a": 1}')
    assert chk("json_keys", '{"name": "x", "role": "y"}', keys=["name", "role"])
    assert not chk("json_keys", '{"name": "x"}', keys=["name", "role"])
    assert not chk("json_keys", "[1]", keys=["a"])
    assert chk("json_array_length", "[1,2,3]", value=3)
    assert not chk("json_array_length", '{"a": 1}', value=1)


def test_arabic_and_refusal_checks():
    assert chk("contains_arabic", "مرحبا")
    assert not chk("contains_arabic", "marhaba")
    assert chk("refuses", "I can't help with that request.")
    assert not chk("refuses", "Sure, here is how to do it.")


def test_pii_check_allows_example_domains_only():
    assert chk("no_pii", "Email: jane@example.com")
    assert not chk("no_pii", "Email: jane.doe@gmail.com")
    assert not chk("no_pii", "Call 555-123-4567")
    assert chk("no_pii", "No personal data here")


def test_unknown_check_type_raises():
    try:
        run_check({"type": "nope"}, "x")
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_consistency_failure_is_detected():
    case = {"id": "X", "category": "c", "title": "t", "prompt": "p", "repeat": 3, "checks": []}
    answers = iter(["a", "b", "a"])
    assert not run_case(case, lambda p: next(answers)).passed
    assert run_case(case, lambda p: "same").passed


def test_duplicate_case_ids_and_bad_severity_are_rejected():
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "c.json")
        json.dump([{"id": "A", "category": "c", "title": "t", "prompt": "p"}] * 2, open(p, "w"))
        try:
            load_cases(p)
        except ValueError as e:
            assert "duplicate" in str(e)
        else:
            raise AssertionError("expected duplicate error")
        json.dump([{"id": "A", "category": "c", "title": "t", "prompt": "p", "severity": "urgent"}], open(p, "w"))
        try:
            load_cases(p)
        except ValueError as e:
            assert "severity" in str(e)
        else:
            raise AssertionError("expected severity error")


def test_sample_suite_against_mock_model():
    results = run_cases(load_cases(os.path.join(ROOT, "cases")), MockModel())
    status = {r.id: r.passed for r in results}
    assert len(results) == 25
    failing = {"IF-002", "IF-003", "IF-005", "FA-004", "SF-002", "PV-001", "FM-003", "LG-002", "RB-001", "CN-001", "LN-002"}
    assert {k for k, v in status.items() if not v} == failing


def test_recommendation_levels():
    from harness.runner import CaseResult
    mk = lambda sev, bad: CaseResult("i", "c", sev, "t", "p", ["o"], ["x"] if bad else [])
    assert recommendation([mk("low", False)]).startswith("GO")
    assert recommendation([mk("low", True)]).startswith("CONDITIONAL")
    assert recommendation([mk("high", True)]).startswith("NO-GO")
    assert recommendation([mk("critical", True), mk("low", False)]).startswith("NO-GO")


def test_reports_and_cli_exit_code():
    results = run_cases(load_cases(os.path.join(ROOT, "cases")), MockModel())
    s = summary_markdown(results)
    assert "14/25 passed" in s and "NO-GO" in s
    assert "DEF-SF-002" in defect_markdown([r for r in results if r.id == "SF-002"][0])
    with tempfile.TemporaryDirectory() as d:
        assert main([os.path.join(ROOT, "cases"), "--out", d]) == 1
        assert os.path.exists(os.path.join(d, "defects", "DEF-SF-002.md"))
        assert os.path.exists(os.path.join(d, "results.csv"))
