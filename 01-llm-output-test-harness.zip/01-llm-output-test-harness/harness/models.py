"""Model adapters. A 'model' is any function: prompt (str) -> answer (str)."""
from __future__ import annotations

import importlib
import json
import os
from collections import defaultdict
from typing import Callable

Model = Callable[[str], str]
HERE = os.path.dirname(os.path.abspath(__file__))


class MockModel:
    """Offline stand-in with canned answers (some intentionally flawed) so the repo runs without an API key.

    Prompts listed under "flaky" return a different answer on each call, to demonstrate consistency testing.
    """

    def __init__(self, path: str | None = None):
        path = path or os.path.join(HERE, "..", "data", "mock_responses.json")
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        self.fixed = data["fixed"]
        self.flaky = data["flaky"]
        self.calls = defaultdict(int)

    def __call__(self, prompt: str) -> str:
        if prompt in self.flaky:
            options = self.flaky[prompt]
            i = self.calls[prompt] % len(options)
            self.calls[prompt] += 1
            return options[i]
        return self.fixed.get(prompt, "I'm not sure what you mean.")


def load_model(spec: str) -> Model:
    """'mock' or 'package.module:function' for a real model client."""
    if spec == "mock":
        return MockModel()
    module, _, func = spec.partition(":")
    if not func:
        raise ValueError("model must be 'mock' or 'module:function'")
    return getattr(importlib.import_module(module), func)
