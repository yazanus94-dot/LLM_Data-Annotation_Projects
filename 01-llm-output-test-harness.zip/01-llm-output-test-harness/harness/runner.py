"""Load test cases, run them against a model and collect results."""
from __future__ import annotations

import glob
import json
import os
from dataclasses import dataclass, field
from typing import Callable, List

from .checks import run_check

SEVERITIES = ("critical", "high", "medium", "low")


@dataclass
class CaseResult:
    id: str
    category: str
    severity: str
    title: str
    prompt: str
    outputs: List[str]
    failures: List[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not self.failures

    @property
    def output(self) -> str:
        return self.outputs[0] if self.outputs else ""


def load_cases(path: str) -> List[dict]:
    files = sorted(glob.glob(os.path.join(path, "*.json"))) if os.path.isdir(path) else [path]
    cases: List[dict] = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            cases.extend(json.load(fh))
    ids = [c["id"] for c in cases]
    dupes = {i for i in ids if ids.count(i) > 1}
    if dupes:
        raise ValueError(f"duplicate case ids: {sorted(dupes)}")
    for c in cases:
        if c.get("severity", "medium") not in SEVERITIES:
            raise ValueError(f"{c['id']}: invalid severity {c.get('severity')!r}")
    return cases


def normalize(text: str) -> str:
    return " ".join(text.lower().split())


def run_case(case: dict, model: Callable[[str], str]) -> CaseResult:
    repeats = int(case.get("repeat", 1))
    outputs = [model(case["prompt"]) for _ in range(repeats)]
    res = CaseResult(case["id"], case["category"], case.get("severity", "medium"), case["title"], case["prompt"], outputs)
    if repeats > 1 and len({normalize(o) for o in outputs}) > 1:
        res.failures.append(f"inconsistent answers across {repeats} runs: {outputs}")
    for spec in case.get("checks", []):
        ok, msg = run_check(spec, outputs[0])
        if not ok:
            res.failures.append(msg)
    return res


def run_cases(cases: List[dict], model: Callable[[str], str]) -> List[CaseResult]:
    return [run_case(c, model) for c in cases]
