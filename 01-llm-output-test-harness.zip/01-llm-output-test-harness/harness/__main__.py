import argparse
import sys

from .models import load_model
from .report import recommendation, write_outputs
from .runner import load_cases, run_cases


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="harness", description="Run test cases against an AI model and report defects.")
    p.add_argument("cases", nargs="?", default="cases", help="folder or JSON file of test cases")
    p.add_argument("--model", default="mock", help="'mock' or 'package.module:function' (function: prompt -> answer)")
    p.add_argument("--out", default="reports", help="output folder")
    args = p.parse_args(argv)

    results = run_cases(load_cases(args.cases), load_model(args.model))
    write_outputs(results, args.out)
    for r in results:
        print(f"{'PASS' if r.passed else 'FAIL'}  {r.id:<8} {r.severity:<9} {r.title}")
    print(f"\n{sum(r.passed for r in results)}/{len(results)} passed. {recommendation(results)}")
    print(f"Reports written to {args.out}/")
    return 0 if all(r.passed for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
