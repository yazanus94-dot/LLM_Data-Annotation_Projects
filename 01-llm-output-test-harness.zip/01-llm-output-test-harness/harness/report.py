"""Markdown report, defect reports and release recommendation."""
from __future__ import annotations

import csv
import os
from collections import defaultdict
from typing import List

from .runner import SEVERITIES, CaseResult


def recommendation(results: List[CaseResult]) -> str:
    failed = [r for r in results if not r.passed]
    if any(r.severity == "critical" for r in failed):
        return "NO-GO: at least one critical failure (safety or privacy)."
    if any(r.severity == "high" for r in failed):
        return "NO-GO: high severity failures must be fixed first."
    if failed:
        return "CONDITIONAL GO: only medium/low failures remain; track them as known issues."
    return "GO: all test cases passed."


def summary_markdown(results: List[CaseResult]) -> str:
    total, passed = len(results), sum(r.passed for r in results)
    out = ["# AI Output Test Report", "", f"**Result:** {passed}/{total} passed ({passed / total:.0%})", "",
           f"**Recommendation:** {recommendation(results)}", "", "## By category", "",
           "| Category | Passed | Failed | Pass rate |", "|---|---|---|---|"]
    cats = defaultdict(list)
    for r in results:
        cats[r.category].append(r)
    for c in sorted(cats):
        p = sum(x.passed for x in cats[c])
        out.append(f"| {c} | {p} | {len(cats[c]) - p} | {p / len(cats[c]):.0%} |")
    out += ["", "## Failures by severity", "", "| Severity | Failed |", "|---|---|"]
    for s in SEVERITIES:
        out.append(f"| {s} | {sum(1 for r in results if not r.passed and r.severity == s)} |")
    out += ["", "## Failed cases", "", "| ID | Severity | Title | Why it failed |", "|---|---|---|---|"]
    for r in sorted((r for r in results if not r.passed), key=lambda r: SEVERITIES.index(r.severity)):
        out.append(f"| {r.id} | {r.severity} | {r.title} | {'; '.join(r.failures)[:140].replace('|', '/')} |")
    return "\n".join(out) + "\n"


def defect_markdown(r: CaseResult) -> str:
    return f"""# DEF-{r.id}: {r.title}

| Field | Value |
|---|---|
| Severity | {r.severity.capitalize()} |
| Category | {r.category} |
| Test case | {r.id} |
| Reproducibility | {len(r.outputs)} run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > {r.prompt}
2. Read the answer.

## Expected result
{chr(10).join('- ' + f for f in r.failures)}

## Actual result
```
{chr(10).join(r.outputs)}
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this {r.category} behavior.
"""


def write_outputs(results: List[CaseResult], out_dir: str) -> None:
    os.makedirs(os.path.join(out_dir, "defects"), exist_ok=True)
    with open(os.path.join(out_dir, "summary.md"), "w", encoding="utf-8") as f:
        f.write(summary_markdown(results))
    with open(os.path.join(out_dir, "results.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "category", "severity", "title", "status", "failures"])
        for r in results:
            w.writerow([r.id, r.category, r.severity, r.title, "PASS" if r.passed else "FAIL", " | ".join(r.failures)])
    for r in results:
        if not r.passed:
            with open(os.path.join(out_dir, "defects", f"DEF-{r.id}.md"), "w", encoding="utf-8") as f:
                f.write(defect_markdown(r))
