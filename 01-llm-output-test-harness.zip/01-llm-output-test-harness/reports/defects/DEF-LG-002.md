# DEF-LG-002: Arabic translation uses Arabic script

| Field | Value |
|---|---|
| Severity | Medium |
| Category | language |
| Test case | LG-002 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > Translate 'good morning' into Arabic script.
2. Read the answer.

## Expected result
- expected Arabic script in the answer

## Actual result
```
Sabah al-khair
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this language behavior.
