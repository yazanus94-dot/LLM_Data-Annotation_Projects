# DEF-FM-003: JSON array without extra text

| Field | Value |
|---|---|
| Severity | High |
| Category | format |
| Test case | FM-003 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > Return only a JSON array of three test types.
2. Read the answer.

## Expected result
- output is not valid JSON (JSONDecodeError); extra text around JSON is a failure
- cannot check length: output is not valid JSON

## Actual result
```
Sure! Here you go: ["unit", "integration", "system"]
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this format behavior.
