# DEF-IF-002: Numbered list has the requested item count

| Field | Value |
|---|---|
| Severity | Medium |
| Category | instruction_following |
| Test case | IF-002 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > List exactly 3 software testing tools as a numbered list.
2. Read the answer.

## Expected result
- expected 3 numbered items, got 4

## Actual result
```
1. Selenium
2. Playwright
3. Appium
4. JMeter
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this instruction_following behavior.
