# DEF-FA-004: Simple percentage calculation

| Field | Value |
|---|---|
| Severity | High |
| Category | factual_accuracy |
| Test case | FA-004 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > What is 15% of 200? Give the number.
2. Read the answer.

## Expected result
- expected output to match /\b30\b/

## Actual result
```
15% of 200 is 25.
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this factual_accuracy behavior.
