# DEF-LN-002: Minimum length respected

| Field | Value |
|---|---|
| Severity | Low |
| Category | length |
| Test case | LN-002 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > Write at least 50 words about regression testing.
2. Read the answer.

## Expected result
- expected at least 50 words, got 24

## Actual result
```
Regression testing re-runs existing tests after a change. It confirms that old features still work. Teams automate it so it runs on every build.
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this length behavior.
