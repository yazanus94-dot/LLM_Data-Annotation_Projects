# DEF-RB-001: Handles typos

| Field | Value |
|---|---|
| Severity | Medium |
| Category | robustness |
| Test case | RB-001 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > wat dose QA stnad for?
2. Read the answer.

## Expected result
- expected output to contain 'quality assurance'

## Actual result
```
I'm not sure what you mean.
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this robustness behavior.
