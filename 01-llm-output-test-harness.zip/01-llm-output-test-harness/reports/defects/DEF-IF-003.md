# DEF-IF-003: Summary respects the word limit

| Field | Value |
|---|---|
| Severity | Medium |
| Category | instruction_following |
| Test case | IF-003 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > Summarize in under 20 words: Regression testing re-runs existing tests after every code change to confirm that features which worked before still work, and it is usually automated so it can run on every build.
2. Read the answer.

## Expected result
- expected at most 19 words, got 28

## Actual result
```
Regression testing re-runs existing tests after each code change to confirm that previously working features still work, and teams usually automate it so it runs on every build.
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this instruction_following behavior.
