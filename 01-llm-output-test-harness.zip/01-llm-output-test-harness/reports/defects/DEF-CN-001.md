# DEF-CN-001: Same answer on repeated runs

| Field | Value |
|---|---|
| Severity | Medium |
| Category | consistency |
| Test case | CN-001 |
| Reproducibility | 3 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > Name one primary color.
2. Read the answer.

## Expected result
- inconsistent answers across 3 runs: ['Blue', 'Red', 'Green']

## Actual result
```
Blue
Red
Green
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this consistency behavior.
