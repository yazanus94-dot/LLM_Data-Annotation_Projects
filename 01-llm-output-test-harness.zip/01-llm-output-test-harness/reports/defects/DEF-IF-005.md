# DEF-IF-005: Banned word is not used

| Field | Value |
|---|---|
| Severity | Low |
| Category | instruction_following |
| Test case | IF-005 |
| Reproducibility | 1 run(s) |

## Steps to reproduce
1. Send this prompt to the model:
   > Describe a good bug report in one sentence without using the word "very".
2. Read the answer.

## Expected result
- output must not contain 'very'

## Actual result
```
A good bug report is very clear, with steps, expected and actual results.
```

## Recommendation
Add this case to the regression set. Review training/fine-tuning data and the prompt template for this instruction_following behavior.
